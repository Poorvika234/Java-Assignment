package com.telstra.dao;

public class UserDao {
	
	public boolean verifyUser(String userName) {
		
		return false;
		
	}
}
