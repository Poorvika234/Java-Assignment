package com.telstra.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.telstra.dao.UserDao;

@Controller
@RequestMapping("/welcome")
public class WelcomeController {
	
	@RequestMapping(value="/welcome", method = RequestMethod.GET)
	public ModelAndView greet() {
		ModelAndView modelAndview = new ModelAndView("greeting");
		return modelAndview;
	}
	
	@RequestMapping(value="userform")
		public String getForm() {
		return "userform";
	}
	
	/*
	 * @RequestMapping(value="/name", method = RequestMethod.GET) public
	 * ModelAndView greetWithName(@RequestParam("userName") String
	 * name, @RequestParam("userLocation") String location) { ModelAndView
	 * modelAndview = new ModelAndView("greeting-name");
	 * modelAndview.addObject("uname",name); modelAndview.addObject("location",
	 * location);
	 * 
	 * //new ModelAndView(viewname, modelName, modelObject) return modelAndview; }
	 */
	
	@RequestMapping(value="/name", method = RequestMethod.GET) 
	public  ModelAndView greetWithName(@RequestParam String userName, @RequestParam  String userLocation) { 
		ModelAndView  modelAndview = new ModelAndView("greeting-user");
		User user = new User();
		user.setUserName(userName);
		user.setUserLocation(userLocation);
		
		UserDao userDao = new UserDao();
		userDao.verifyUser(userName);
		
		modelAndview.addObject("uname",user);
	 return modelAndview;
	}
	 
	@RequestMapping(value="/name/{username}", method = RequestMethod.GET)
	public ModelAndView greetWithName1(@PathVariable ("username") String name) {	
		ModelAndView modelAndview = new ModelAndView("greeting-name","uname",name);
		return modelAndview;	
}
}